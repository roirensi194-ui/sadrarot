# Caderno — Android

Aplicativo Android nativo em Kotlin + Jetpack Compose, com tema escuro e banco local Room.

## O que já funciona
- Criar, editar e excluir blocos de anotação.
- Persistência local dos blocos e textos usando Room.
- Anexar imagens e vídeos por meio do seletor de documentos do Android.
- Abrir anexos no aplicativo compatível do aparelho.
- Pesquisar palavras no título e no texto dos blocos.
- Atalho para pesquisar a pergunta na internet quando quiser complementar o conteúdo.

## Limites desta primeira versão
A pesquisa ainda não é um chatbot com IA: ela localiza conteúdo textual já salvo e oferece uma pesquisa externa no navegador. Para responder em linguagem natural usando o conteúdo dos blocos e depois consultar fontes online, é necessário conectar um serviço de IA e uma API de busca por meio de um backend seguro. Não coloque chaves secretas diretamente no aplicativo.

Os anexos são mantidos como referências persistentes aos arquivos selecionados pelo usuário. Se o arquivo original for removido ou o acesso for revogado pelo sistema, o anexo poderá deixar de abrir. Uma próxima versão pode copiar os arquivos para armazenamento privado do app.

## Como gerar o APK
1. Instale o Android Studio (versão recente).
2. Abra a pasta deste projeto no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos: JDK 17 e Android SDK 35.
