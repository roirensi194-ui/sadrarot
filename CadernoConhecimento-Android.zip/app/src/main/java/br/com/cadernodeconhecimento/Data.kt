package br.com.cadernodeconhecimento

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "blocks")
data class NoteBlock(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String = "",
    val parentId: Long? = null,
    val mediaUris: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface BlockDao {
    @Query("SELECT * FROM blocks ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<NoteBlock>>

    @Query("SELECT * FROM blocks WHERE id = :id LIMIT 1")
    suspend fun get(id: Long): NoteBlock?

    @Insert
    suspend fun insert(block: NoteBlock): Long

    @Update
    suspend fun update(block: NoteBlock)

    @Delete
    suspend fun delete(block: NoteBlock)

    @Query("SELECT * FROM blocks WHERE title LIKE '%' || :q || '%' OR body LIKE '%' || :q || '%' ORDER BY updatedAt DESC")
    suspend fun search(q: String): List<NoteBlock>
}

@Database(entities = [NoteBlock::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun blockDao(): BlockDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context, AppDatabase::class.java, "caderno.db")
                .fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}
