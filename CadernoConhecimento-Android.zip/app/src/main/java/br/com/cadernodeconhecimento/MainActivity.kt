package br.com.cadernodeconhecimento

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Accent = Color(0xFFB8A4FF)
private val Muted = Color(0xFF9A9CA5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.get(this).blockDao()
        setContent { CadernoApp(dao) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CadernoApp(dao: BlockDao) {
    val context = LocalContext.current
    val blocks by dao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    var selected by remember { mutableStateOf<NoteBlock?>(null) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<NoteBlock>?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val current = selected ?: return@rememberLauncherForActivityResult
        uris.forEach { uri ->
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
        val merged = (current.mediaUris.split("|").filter { it.isNotBlank() } + uris.map { it.toString() }).distinct()
        val updated = current.copy(mediaUris = merged.joinToString("|"), updatedAt = System.currentTimeMillis())
        selected = updated
        kotlinx.coroutines.MainScope().launch { dao.update(updated) }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent, onBackground = Color.White,
        onSurface = Color.White, secondary = Muted
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (selected != null) {
                BlockEditor(
                    block = selected!!,
                    onBack = { selected = null },
                    onSave = { updated ->
                        selected = updated
                        kotlinx.coroutines.MainScope().launch { dao.update(updated) }
                    },
                    onAttach = { mediaPicker.launch(arrayOf("image/*", "video/*")) },
                    onDelete = {
                        val item = selected!!
                        kotlinx.coroutines.MainScope().launch { dao.delete(item) }
                        selected = null
                    }
                )
            } else {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("CADERNO", color = Accent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text("Seu conhecimento, organizado.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                        FilledIconButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, contentDescription = "Novo bloco") }
                    }
                    Spacer(Modifier.height(20.dp))
                    OutlinedTextField(
                        value = query, onValueChange = { query = it; results = null },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Pesquisar nos seus blocos...") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        trailingIcon = {
                            IconButton(onClick = {
                                kotlinx.coroutines.MainScope().launch { results = dao.search(query.trim()) }
                            }) { Icon(Icons.Default.Search, "Buscar") }
                        },
                        shape = RoundedCornerShape(16.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    if (query.isNotBlank()) {
                        TextButton(onClick = {
                            val url = "https://www.google.com/search?q=" + Uri.encode(query)
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        }) { Text("Pesquisar na internet sobre “$query”") }
                    }
                    Text(if (results != null) "RESULTADOS LOCAIS" else "MEUS BLOCOS", color = Muted, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(8.dp))
                    val shown = results ?: blocks
                    if (shown.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(if (results != null) "Nenhum bloco encontrado." else "Ainda não há blocos. Crie o primeiro.", color = Muted)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(shown, key = { it.id }) { block ->
                                BlockCard(block) { selected = block }
                            }
                        }
                    }
                    if (results != null) TextButton(onClick = { results = null }) { Text("Voltar para todos os blocos") }
                }
            }
        }
    }
    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("Novo bloco") },
            text = { OutlinedTextField(value = newTitle, onValueChange = { newTitle = it }, label = { Text("Nome do bloco") }) },
            confirmButton = {
                TextButton(onClick = {
                    if (newTitle.isNotBlank()) {
                        val title = newTitle.trim()
                        kotlinx.coroutines.MainScope().launch {
                            val id = dao.insert(NoteBlock(title = title))
                            selected = dao.get(id)
                        }
                        newTitle = ""; showCreate = false
                    }
                }) { Text("Criar") }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun BlockCard(block: NoteBlock, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(block.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (block.body.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(block.body.take(130), color = Muted, style = MaterialTheme.typography.bodyMedium)
            }
            val mediaCount = block.mediaUris.split("|").count { it.isNotBlank() }
            if (mediaCount > 0) {
                Spacer(Modifier.height(8.dp))
                Text("$mediaCount arquivo(s) anexado(s)", color = Accent, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BlockEditor(
    block: NoteBlock,
    onBack: () -> Unit,
    onSave: (NoteBlock) -> Unit,
    onAttach: () -> Unit,
    onDelete: () -> Unit
) {
    var title by remember(block.id) { mutableStateOf(block.title) }
    var body by remember(block.id) { mutableStateOf(block.body) }
    val context = LocalContext.current
    val media = block.mediaUris.split("|").filter { it.isNotBlank() }

    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
            Text("EDITAR BLOCO", color = Accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Excluir", tint = Color(0xFFE28C8C)) }
        }
        OutlinedTextField(
            value = title, onValueChange = { title = it },
            modifier = Modifier.fillMaxWidth(), textStyle = MaterialTheme.typography.headlineSmall,
            placeholder = { Text("Título do bloco") }, shape = RoundedCornerShape(14.dp)
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = body, onValueChange = { body = it },
            modifier = Modifier.fillMaxWidth().weight(1f),
            placeholder = { Text("Escreva suas informações, tópicos, citações e referências...") },
            shape = RoundedCornerShape(14.dp)
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onAttach) {
                Icon(Icons.Default.AttachFile, null); Spacer(Modifier.width(6.dp)); Text("Anexar imagem/vídeo")
            }
            Spacer(Modifier.width(8.dp))
            Text("${media.size} anexo(s)", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        media.forEachIndexed { index, uri ->
            TextButton(onClick = {
                val mime = context.contentResolver.getType(Uri.parse(uri)) ?: "*/*"
                context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.parse(uri), mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }) { Text("Abrir anexo ${index + 1}") }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onBackSave@{
                onSave(block.copy(title = title.ifBlank { "Sem título" }, body = body, updatedAt = System.currentTimeMillis()))
                onBack()
            },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
        ) { Text("Salvar alterações") }
    }
}
